package Server;

import Util.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.StringTokenizer;

public class ThreadServer implements Runnable {

    public HashMap<String, SocketWrapper> socketMap;
    RestaurantDatabaseSystem rds;
    String name;
    SocketWrapper socketWrapper;
    private Thread thr;
    private ArrayList<Food> orderedFood ;
    String rsName;

    public ThreadServer(RestaurantDatabaseSystem rds, SocketWrapper socketWrapper, ArrayList<Food> orderedFood, String rsName) {
        this.rds = rds;
        this.socketWrapper = socketWrapper;
        this.thr = new Thread(this);
        this.orderedFood = orderedFood;
        this.rsName= rsName;
        thr.start();
    }

    @Override
    public void run() {
        try {
//            Object obj = null;
            while(true)
            {
//                obj = socketWrapper.read();
//                System.out.println(obj);
                String s = (String) socketWrapper.read();
                System.out.println("Server read : " + s);

                StringTokenizer st = new StringTokenizer(s,",");
                String command = st.nextToken();
                String response = "";
                if(command.equalsIgnoreCase("viewrestaurant"))
                {
                    int viewtype = Integer.parseInt(st.nextToken());
                    //String response = "";

                    if(viewtype == 1) {

                        ArrayList<Restaurant> rstList = rds.getRestaurants();

                        for (Restaurant rst : rstList) {
                            response += rst + ",";
                        }
                        //socketWrapper.write(response);
                    }
                    else if(viewtype == 2)
                    {
                        String rsname =st.nextToken();
                        ArrayList<Restaurant> rstList = (ArrayList<Restaurant>) rds.searchRestaurantByName(rsname);
                        if(rstList.isEmpty())
                        {
                            response = "No such restaurant with this name";
                        }
                        for (Restaurant rst : rstList) {
                            response += rst + ",";
                        }

                    }
                    else if(viewtype == 3)
                    {
                        String rsCat =st.nextToken();
                        ArrayList<Restaurant> rstList = (ArrayList<Restaurant>) rds.searchRestaurantByCategory(rsCat);
                        if(rstList.isEmpty())
                        {
                            response = "No such restaurant with this category";
                        }
                        for (Restaurant rst : rstList) {
                            response += rst + ",";
                        }
                    }
                    else if(viewtype == 4)
                    {
                       Double rsScore1 = Double.parseDouble(st.nextToken());
                       Double rsScore2 = Double.parseDouble(st.nextToken());
                       ArrayList<Restaurant> rstList = (ArrayList<Restaurant>) rds.searchRestaurantByScore(rsScore1, rsScore2);
                        if(rstList.isEmpty())
                        {
                            response = "No such restaurant with this score";
                        }
                        for (Restaurant rst : rstList) {
                            response += rst + ",";
                        }
                    }
                    else if(viewtype == 5)
                    {
                        String price = st.nextToken();
                        //System.out.println(price);
                        ArrayList<Restaurant> rstList = (ArrayList<Restaurant>) rds.searchRestaurantByPrice(price);
                        if(rstList.isEmpty())
                        {
                            response = "No such restaurant with this price";
                        }
                        for (Restaurant rst : rstList) {
                            response += rst + ",";
                        }
                    }
//                    System.out.println(response);
//                    socketWrapper.write(response);
                }
                else if(command.equalsIgnoreCase("viewfood"))
                {
                    int viewType = Integer.parseInt(st.nextToken());
                    //String response = "";
                    if(viewType == 1)
                    {
                        ArrayList<Food> foodList = rds.getMenu();
                        for(Food fd: foodList)
                        {
                            response += fd + ",";
                        }

                    }
                    else if(viewType == 2)
                    {
                        String name = st.nextToken();
                        ArrayList<Food> foodList = (ArrayList<Food>) rds.searchFoodByName(name);
                        if(foodList.isEmpty())
                        {
                            response = "No such food item with this name";
                        }
                        for(Food fd: foodList)
                        {
                            response += fd + ",";
                        }
                    }
                    else if(viewType == 3)
                    {
                        String category = st.nextToken();
                        ArrayList<Food> foodList = (ArrayList<Food>) rds.searchFoodByCategory(category);
                        if(foodList.isEmpty())
                        {
                            response = "No such food item with this category";
                        }
                        for(Food fd: foodList)
                        {
                            response += fd + ",";
                        }
                    }
                    else if(viewType == 4)
                    {
                        double lprice = Double.parseDouble(st.nextToken());
                        double rprice = Double.parseDouble(st.nextToken());
                        ArrayList<Food> foodList = (ArrayList<Food>) rds.byPriceRange(lprice, rprice);
                        if(foodList.isEmpty())
                        {
                            response = "No such food item with this price range";
                        }
                        for(Food fd: foodList)
                        {
                            response += fd + ",";
                        }
                    }
                    else if(viewType == 5)
                    {
                        String restName = st.nextToken();
                        String foodName = st.nextToken();
                        ArrayList<Food> foodList = (ArrayList<Food>) rds.searchFoodInRestaurant(foodName, restName);
                        if(foodList.isEmpty())
                        {
                            response = "No such food item with this price name";
                        }
                        for(Food fd: foodList)
                        {
                            response += fd + ",";
                        }
                    }
                    else if(viewType == 6)
                    {
                        String restName = st.nextToken();
                        String category = st.nextToken();
                        List<Food> foodList =rds.searchCategoryInRestaurant(restName,category);
                        if(foodList.isEmpty())
                        {
                            response = "No such food item with this category";
                        }
                        for(Food fd: foodList)
                        {
                            response += fd + ",";
                        }
                    }
                    else if(viewType == 7)
                    {
                        String restName = st.nextToken();
                        double lPrice = Double.parseDouble(st.nextToken());
                        double rPrice = Double.parseDouble(st.nextToken());
                        List<Food> foodList = rds.byPriceRangeInRestaurant(restName,lPrice,rPrice);
                        if(foodList.isEmpty())
                        {
                            response = "No such food item with this range";
                        }
                        for(Food fd: foodList)
                        {
                            response += fd + ",";
                        }
                    }
                    else if(viewType == 8)
                    {
                       String restName = st.nextToken();
                       List<Food> foodList = rds.costliestFoodItems(restName);
                        if(foodList.isEmpty())
                        {
                            response = "No such restaurants";
                        }
                        for(Food fd: foodList)
                        {
                            response += fd + ",";
                        }
                    }
                    else if(viewType == 9)
                    {
                        String restName = st.nextToken();
                        List<Food> foodList = rds.viewMenu(restName);
                        if(foodList.isEmpty())
                        {
                            response = "No such restaurant";
                        }
                        for(Food fd: foodList)
                        {
                            response += fd + ",";
                        }
                    }
                }

                else if(command.equalsIgnoreCase("orderfood"))
                {
                    Food fd = new Food(Integer.parseInt(st.nextToken()),st.nextToken(),Integer.parseInt(st.nextToken()));
                    orderedFood.add(fd);
                    response = "foodOrdered";
                }
                else if(command.equalsIgnoreCase("vieworder"))
                {
                    List<Restaurant> rsl = rds.searchRestaurantByName(rsName);
                    Restaurant rs = rsl.get(0);
                    for(Food fd: orderedFood)
                    {
                        if(rs.getId() == fd.getRestaurantId()) {
                            response += fd.getOrderString() + ",";
                        }
                    }

                }
                else if(command.equalsIgnoreCase("viewmenu"))
                {
                    List<Restaurant> rsl = rds.searchRestaurantByName(rsName);
                    Restaurant rs = rsl.get(0);
                    List<Food> foodList = rs.getMenu();
                    for(Food fd: foodList)
                    {
                        response += fd.getMenuString() + ",";
                    }
                }
                else if(command.equalsIgnoreCase("verifylogin"))
                {
                    String restname = st.nextToken();
                    rsName = restname;
                    int pass = Integer.parseInt(st.nextToken());
                    List<Restaurant> rsList = rds.searchRestaurantByName(restname);
                    if(rsList.isEmpty())
                    {
                        response = "no restaurant";
                    }
                    else {
                        if(pass == 2105161)
                            response = "valid";
                        else
                            response = "invalid";
                    }
                }
                else if(command.equals("viewRest"))
                {
                    List<Restaurant> rstList = rds.searchRestaurantByName(rsName);
                    for (Restaurant rst : rstList) {
                        response += rst + ",";
                    }
                }
                System.out.println(response);
                socketWrapper.write(response);
            }
        } catch (Exception e) {
            System.out.println(e);
        } finally {
            try {
                socketWrapper.closeConnection();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}

