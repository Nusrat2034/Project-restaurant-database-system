package Server;

import Util.Food;
import Util.Restaurant;
import Util.RestaurantDatabaseSystem;
import Util.SocketWrapper;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;

public class Server {

//    public static ArrayList<Restaurant> restaurants;
//    public static HashMap<String, SocketWrapper> socketMap;
//    public HashMap<String, String> clientMap;
    RestaurantDatabaseSystem rds;
    private ServerSocket serverSocket;
    private ArrayList<Food> orderedFood ;
    String rsName = "";
    public Server() throws Exception
    {
        rds = new RestaurantDatabaseSystem();

//        restaurants = new ArrayList<>();
//        restaurants = rds.getRestaurants();
//        socketMap = new HashMap<>();
//        clientMap = new HashMap<>();
        orderedFood = new ArrayList<>();
        try {
            serverSocket = new ServerSocket(5161);
            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("Accepted");
                serve(clientSocket);
            }
        } catch (Exception e) {
            System.out.println("Server starts:" + e);
        }
    }
    public void serve(Socket clientSocket) throws IOException
    {
        SocketWrapper socketWrapper = new SocketWrapper(clientSocket);

        new ThreadServer(rds, socketWrapper, orderedFood, rsName);
    }

    public static void main(String[] args) throws Exception {
       Server server = new Server();
    }
}

