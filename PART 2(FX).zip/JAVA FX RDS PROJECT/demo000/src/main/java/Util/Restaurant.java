package Util;

import javafx.scene.control.skin.MenuButtonSkinBase;

import java.util.*;

public class Restaurant {
    ArrayList<String> categories;
    private int Id;
    private String restaurantName;
    private double score;
    private String price;
    private String zipCode;
    private String category1, category2, category3;
    private ArrayList<Food> Menu;



    public Restaurant(int Id, String restaurantName, double score, String price, String zipCode, ArrayList<String> categories) {
        this.Id = Id;
        this.restaurantName = restaurantName;
        this.score = score;
        this.price = price;
        this.zipCode = zipCode;
        this.categories = categories;
        Menu = new ArrayList<>();
    }

    public Restaurant(int id, String restaurantName, double score, String price, String zipCode) {
        Id = id;
        this.restaurantName = restaurantName;
        this.score = score;
        this.price = price;
        this.zipCode = zipCode;
        Menu = new ArrayList<>();
    }

    public Restaurant()
    {
        Id = 0;
        restaurantName = "";
        score = 0.0;
        price = "";
        zipCode = "";
        category1 = "";
        category2 = "";
        category3 = "";
        Menu = new ArrayList<>();
    }

    public Restaurant(int id, String restaurantName, double score, String price, String zipCode, String category1, String category2, String category3) {
        Id = id;
        this.restaurantName = restaurantName;
        this.score = score;
        this.price = price;
        this.zipCode = zipCode;
        this.category1 = category1;
        this.category2 = category2;
        this.category3 = category3;
        Menu = new ArrayList<>();
    }

    public String getCategory1() {
        return category1;
    }

    public String getCategory2() {
        return category2;
    }

    public String getCategory3() {
        return category3;
    }

    public int getId() {
        return Id;
    }

    public void setId(int Id1) {
        this.Id = Id1;
    }

    public ArrayList<String> getCategory() {
        return categories;
    }

    public void setCategory1(String category1) {
        this.category1 = category1;
    }

    public void setCategory2(String category2) {
        this.category2 = category2;
    }

    public void setCategory3(String category3) {
        this.category3 = category3;
    }

    public void setMenu(ArrayList<Food> menu) {
        Menu = menu;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode1) {
        this.zipCode = zipCode1;
    }

    public double getScore() {
        return score;
    }

    public void setScore(double score1) {
        this.score = score1;
    }

    public String getRestaurantName() {
        return restaurantName;
    }

    public void setRestaurantName(String restaurantName1) {
        this.restaurantName = restaurantName1;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price1) {
        this.price = price1;
    }

    public void addFoodToMenu(Food fd) {
        Menu.add(fd);
    }

    public List<Food> getFoodByName(String foodName) {
        List<Food> foodList = new ArrayList<>();
        for (Food fd : Menu) {
            if (fd.getFoodName().toLowerCase().contains(foodName.toLowerCase()))
                foodList.add(fd);
        }
        return foodList;
    }

    public List<Food> getFoodByCategory(String categ) {
        List<Food> foodList = new ArrayList<>();
        for (Food fd : Menu) {
            if (fd.getCategory().toLowerCase().contains(categ.toLowerCase()))
                foodList.add(fd);
        }
        return foodList;
    }

    public List<Food> getFoodByPriceRange(double lPrice, double rPrice) {
        List<Food> foodList = new ArrayList<>();
        for (Food fd : Menu) {
            if (fd.getPrice() >= lPrice && fd.getPrice() <= rPrice)
                foodList.add(fd);
        }
        return foodList;
    }

    public List<Food> costliestFoodItems() {
        List<Food> foodList = new ArrayList<>();
        double maxPrice = -1;
        for (Food fd : Menu) {
            if (fd.getPrice() > maxPrice)
                maxPrice = fd.getPrice();
        }
        for (Food fd : Menu) {
            if (fd.getPrice() == maxPrice)
                foodList.add(fd);
        }
        return foodList;
    }

    public ArrayList<String> getCategories() {
        return categories;
    }

    public void setCategories(ArrayList<String> categories) {
        this.categories = categories;
    }

    public ArrayList<Food> getMenu() {
        return Menu;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();

        sb.append(Id).append(",");
        sb.append(restaurantName).append(",");
        sb.append(score).append(",");
        sb.append(price).append(",");
        sb.append(zipCode).append(",");

        if (categories != null) {
            int size = categories.size();
            if (size > 0) {
                sb.append(categories.get(0));
            }

            for (int i = 1; i < 3; i++) {
                sb.append(",");
                if (i < size) {
                    sb.append(categories.get(i));
                } else {
                    sb.append("null");
                }
            }
        } else {
            sb.append("null,null,null");
        }

        return sb.toString();
    }

    void showDetails() {
        System.out.println("ID: " + Id);
        System.out.println("Restaurant name: " + restaurantName);
        System.out.println("Score: " + score);
        System.out.println("Price: " + price);
        System.out.println("Zip Code: " + zipCode);
        System.out.print("Category: ");
        int i;
        for (i = 0; i < categories.size() - 1; i++) {
            System.out.print(categories.get(i) + " , ");
        }
        System.out.print(categories.get(i));
        System.out.println();
        System.out.println();
    }
}