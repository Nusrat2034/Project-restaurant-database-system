package Util;

import java.util.*;
import java.io.*;

public class RestaurantDatabaseSystem {
    private ArrayList<Restaurant> restaurants;
    private ArrayList<Food> menu;
    Set<String> allCategories;
    private static final String RESTAURANT_OUTPUT_FILE_NAME = "restaurant.txt";
    private static final String MENU_OUTPUT_FILE_NAME = "menu.txt";

    public RestaurantDatabaseSystem() throws Exception {
        restaurants = new ArrayList<>();
        menu = new ArrayList<>();
        allCategories = new TreeSet<>();

        InputStream restaurantInputStream = RestaurantDatabaseSystem.class.getResourceAsStream("restaurant.txt");
        assert restaurantInputStream != null;
        BufferedReader brR = new BufferedReader(new InputStreamReader(restaurantInputStream));

        InputStream menuInputStream = RestaurantDatabaseSystem.class.getResourceAsStream("menu.txt");
        assert menuInputStream != null;
        BufferedReader brM = new BufferedReader(new InputStreamReader(menuInputStream));

        while (true) {
            String line = brR.readLine();
            if (line == null)
                break;
            String[] array = line.split(",", -1);
            ArrayList<String> list = new ArrayList<>();

            for (int i = 5; i < array.length; i++) {
                if (!array[i].isEmpty()) {
                    list.add(array[i]);
                    allCategories.add(array[i]);
                }
            }

            Restaurant rt = new Restaurant(Integer.parseInt(array[0]), array[1], Double.parseDouble(array[2]), array[3], array[4], list);
            restaurants.add(rt);
        }
        brR.close();


        while (true) {
            String line = brM.readLine();
            if (line == null) break;
            String[] array = line.split(",", -1);
            Food fd = new Food(Integer.parseInt(array[0]), array[1], array[2], Double.parseDouble(array[3]));
            menu.add(fd);
        }
        brM.close();

        for(Restaurant rt : restaurants)
        {
            for(Food fd: menu){
                if(fd.getRestaurantId() == rt.getId())
                    rt.addFoodToMenu(fd);
            }
        }
    }

    private boolean foodExists(String food, int resId) {
        for (Food fd : menu) {
            if (fd.getFoodName().equalsIgnoreCase(food) && fd.getRestaurantId() == resId)
                return true;
        }
        return false;
    }

    private List<Food> restaurantMenu(int rsId) {
        List<Food> menuList = new ArrayList<>();
        for (Food fd : menu) {
            if (fd.getRestaurantId() == rsId)
                menuList.add(fd);
        }
        return menuList;
    }

    public ArrayList<Restaurant> getRestaurants() {
        return restaurants;
    }

    public ArrayList<Food> getMenu() {
        return menu;
    }

    Set<String> getAllCategories() {
        return allCategories;
    }

    public boolean addRestaurant(Restaurant res) {
        if (!restaurantExists(res)) {
            restaurants.add(res);
            ArrayList<String> cats = res.getCategory();
            for (String cat : cats) {
                if (!cat.isEmpty())
                    allCategories.add(cat);
            }
            return true;
        }
        return false;
    }

    public int getTotalFood(int id) {
        int cnt = 0;
        for (Food food : menu) {
            if (food.getRestaurantId() == id)
                cnt++;
        }
        return cnt;
    }

    public boolean isRestaurant(int Id){
        for (Restaurant res : restaurants) {
            if (res.getId() == Id)
                return true;
        }
        return false;
    }

    private boolean restaurantExists(Restaurant rs) {
        for (Restaurant res : restaurants)
        {
            if (res.getId() == rs.getId() || res.getZipCode().equals(rs.getZipCode()) || res.getRestaurantName().equalsIgnoreCase(rs.getRestaurantName()))
                return true;
        }
        return false;
    }

    //1
    public List<Restaurant> searchRestaurantByName(String name) {
        List<Restaurant> foundList = new ArrayList<>();
        for (Restaurant res : restaurants) {
            if (res.getRestaurantName().toLowerCase().contains(name.toLowerCase())) {
                foundList.add(res);
            }
        }
        return foundList;
    }

    //2
    public ArrayList<Restaurant> searchRestaurantByScore(double scr1, double scr2) {

        ArrayList<Restaurant> listByScore = new ArrayList<>();
        for (Restaurant rest : restaurants) {
            double scr = rest.getScore();
            if (scr >= scr1 && scr <= scr2)
                listByScore.add(rest);
        }
        return listByScore;
    }

    //3
    public ArrayList<Restaurant> searchRestaurantByCategory(String category)
    {
        ArrayList<Restaurant> res = new ArrayList<>();
        for (Restaurant rest : restaurants)
        {
            ArrayList<String> categories = rest.getCategory();
            for (String ctg : categories)
            {
                if (ctg.toLowerCase().contains(category.toLowerCase()))
                    res.add(rest);
            }
        }
        return res;
    }

    //4
    public ArrayList<Restaurant> searchRestaurantByPrice(String price) {
        ArrayList<Restaurant> res = new ArrayList<>();
        for (Restaurant rest : restaurants) {
            String prc = rest.getPrice();
            if (prc.equals(price))
                res.add(rest);
        }
        return res;
    }

    //5
    public Restaurant searchRestaurantByZipCode(String zip) {
        for (Restaurant rest : restaurants) {
            String zp = rest.getZipCode();
            if (Objects.equals(zp, zip))
                return rest;
        }
        return null;
    }

    //6
    public ArrayList<ArrayList<String>> categoryWiseRestaurants() {
        ArrayList<ArrayList<String>> categoryBasedRest = new ArrayList<>();
        for (String allCategory : allCategories) {
            ArrayList<String> restaurantList = new ArrayList<>();
            restaurantList.add(allCategory);
            for (Restaurant res : restaurants) {
                if (res.getCategory().contains(allCategory))
                    restaurantList.add(res.getRestaurantName());
            }
            categoryBasedRest.add(restaurantList);
        }
        return categoryBasedRest;
    }

    public boolean addFoodToMenu(Food food) {
        if (isRestaurant(food.getRestaurantId())) {
            if (!foodExists(food.getFoodName(), food.getRestaurantId())) {
                menu.add(food);
                return true;
            }
        }
        return false;
    }

    //1
    public List<Food> searchFoodByName(String foodName) {
        List<Food> matchedFoods = new ArrayList<>();
        for (Food fd : menu) {
            if (fd.getFoodName().toLowerCase().contains(foodName.toLowerCase()))
                matchedFoods.add(fd);
        }
        return matchedFoods;
    }

    //2
    public List<Food> searchFoodInRestaurant(String foodItem, String restName)
    {
        List<Food> foodInRestaurant = new ArrayList<>();
        for(Restaurant restaurant : restaurants)
        {
            if(restaurant.getRestaurantName().equalsIgnoreCase(restName))
                foodInRestaurant = restaurant.getFoodByName(foodItem);
        }
        return foodInRestaurant;
    }

    //3
    public List<Food> searchFoodByCategory(String foodCat) {
        List<Food> categoryBasedFoods = new ArrayList<>();
        for (Food fd : menu) {
            if (fd.getCategory().toLowerCase().contains(foodCat.toLowerCase()))
                categoryBasedFoods.add(fd);
        }
        return categoryBasedFoods;
    }

    //Food4
    public List<Food> searchCategoryInRestaurant(String restName, String category) {
        List<Food> categoryBasedMenu = new ArrayList<>();
        for(Restaurant restaurant : restaurants)
        {
            if(restaurant.getRestaurantName().equalsIgnoreCase(restName))
                categoryBasedMenu = restaurant.getFoodByCategory(category);
        }
        return categoryBasedMenu;
    }

    public Restaurant getRestaurantById(int id)
    {
        for(Restaurant rst : restaurants)
        {
            if(rst.getId() == id)
                return rst;
        }
        return null;
    }
    public List<Food> viewMenu(String restname)
    {
        List<Food> restMenu = new ArrayList<>() ;
        for(Restaurant rst: restaurants)
        {
            if(rst.getRestaurantName().equalsIgnoreCase(restname))
                restMenu = rst.getMenu();
        }
        return restMenu;
    }
    //food5
    public List<Food> byPriceRange(double p1, double p2) {
        List<Food> priceBasedList = new ArrayList<>();
        for (Food fd : menu) {
            if (fd.getPrice() >= p1 && fd.getPrice() <= p2)
                priceBasedList.add(fd);
        }
        return priceBasedList;
    }

    //FooD6
    public List<Food> byPriceRangeInRestaurant(String restName, double p1, double p2) {
        List<Food> priceBasedList = new ArrayList<>();
        for(Restaurant restaurant : restaurants)
        {
            if(restaurant.getRestaurantName().equalsIgnoreCase(restName))
                priceBasedList = restaurant.getFoodByPriceRange(p1,p2);
        }
        return priceBasedList;
    }

    //FOOD7
    public List<Food> costliestFoodItems(String restName) {

        List<Food> costliestItems = new ArrayList<>();
        for(Restaurant restaurant : restaurants)
        {
            if(restaurant.getRestaurantName().equalsIgnoreCase(restName))
                costliestItems = restaurant.costliestFoodItems();
        }
        return costliestItems;
    }

    //FOOD8
    public Map<String, Integer> showTotalFoodCount() {
        Map<String, Integer> totalFoodCount = new HashMap<>();
        for (Restaurant res : restaurants) {
            int total = getTotalFood(res.getId());
            String name = res.getRestaurantName();
            totalFoodCount.put(name, total);
        }
        return totalFoodCount;
    }


    public void writeBack() throws Exception {
        String resourceFolderPath = Objects.requireNonNull(RestaurantDatabaseSystem.class.getResource("")).getPath();

        String restaurantOutputFilePath = resourceFolderPath + RESTAURANT_OUTPUT_FILE_NAME;
        BufferedWriter bw = new BufferedWriter(new FileWriter(restaurantOutputFilePath));
        //BufferedWriter bw = new BufferedWriter(new FileWriter(RESTAURANT_OUTPUT_FILE_NAME));

        StringBuilder s;
        for (Restaurant rt : restaurants) {
            s = new StringBuilder();
            s.append(rt.getId()).append(",").append(rt.getRestaurantName()).append(",").append(rt.getScore()).append(",").append(rt.getPrice()).append(",").append(rt.getZipCode()).append(",");
            List<String> categories = rt.getCategory();
            for (int i = 0; i < categories.size() - 1; i++)
            {
                s.append(categories.get(i)).append(",");
            }

            s.append(categories.get(categories.size() - 1));
            if (categories.size() < 3)
                s.append(",");

            bw.write(s.toString());
            bw.write(System.lineSeparator());
        }
        bw.close();

        String menuOutputFilePath = resourceFolderPath + MENU_OUTPUT_FILE_NAME;
        BufferedWriter bwFood = new BufferedWriter(new FileWriter(menuOutputFilePath));

        //BufferedWriter bwFood = new BufferedWriter(new FileWriter(MENU_OUTPUT_FILE_NAME));
        StringBuilder fd;
        for (Food food : menu) {
            fd = new StringBuilder();
            fd.append(food.getRestaurantId()).append(",").append(food.getCategory()).append(",").append(food.getFoodName()).append(",").append(food.getPrice());
            bwFood.write(fd.toString());
            bwFood.write(System.lineSeparator());
        }
        bwFood.close();
    }
}
