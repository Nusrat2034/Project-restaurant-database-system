package Util;

import java.util.*;

public class RestaurantApp {
    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) throws Exception {
        RestaurantDatabaseSystem rds = new RestaurantDatabaseSystem();

        while (true) {
            System.out.println("""
                    Main Menu:\s
                    1) Search Restaurants
                    2) Search Food Items
                    3) Add Restaurant
                    4) Add Food Item to the Menu
                    5) Exit System""");
            int choice = sc.nextInt();
            sc.nextLine();
            switch (choice) {
                case 1: {
                    searchRestaurants(rds);
                    break;
                }
                case 2: {
                    searchFoodItems(rds);
                    break;
                }
                case 3: {
                    addRestaurant(rds);
                    break;
                }
                case 4: {
                    addFood(rds);
                    break;
                }
                case 5: {
                    rds.writeBack();
                    return;
                }
                default: {
                    System.out.println("Invalid input. your choice must be in between 1-5");
                }
            }


        }
    }

    private static void addRestaurant(RestaurantDatabaseSystem rds) {
        System.out.println("Enter Restaurant Id: ");
        int restaurantId = sc.nextInt();
        sc.nextLine();

        System.out.println("Enter Restaurant name: ");
        String restaurantName = sc.nextLine().trim();

        System.out.print("Enter Restaurant Score: ");
        double score = sc.nextDouble();
        sc.nextLine();

        System.out.print("Enter Restaurant Price (in $): ");
        String price = sc.next().trim();
        sc.nextLine();

        System.out.print("Enter Restaurant Zip Code: ");
        String zipCode = sc.nextLine().trim();

        ArrayList<String> categories = new ArrayList<>();
        for (int i = 1; i <= 3; i++) {
            System.out.print("Enter Category " + i + " :");
            String category = sc.nextLine();
            if (!category.isEmpty())
                categories.add(category);
            else
                break;
        }
        Restaurant restaurant = new Restaurant(restaurantId, restaurantName, score, price, zipCode, categories);

        boolean flag = rds.addRestaurant(restaurant);
        if (flag)
            System.out.println("Restaurant Added Successfully!");
        else
            System.out.println("Restaurant " + restaurantName + " already exists!");
    }

    private static void addFood(RestaurantDatabaseSystem rds) {
        System.out.print("Enter Restaurant ID: ");
        int restaurantID = sc.nextInt();
        sc.nextLine();

        System.out.println("Enter Category of Food: ");
        String category = sc.nextLine();

        System.out.println("Enter Food Name: ");
        String foodName = sc.nextLine().trim();

        System.out.println("Enter Price of the Food");
        double price = sc.nextDouble();
        sc.nextLine();

        Food food = new Food(restaurantID, category, foodName, price);
        boolean flag = rds.addFoodToMenu(food);
        if (flag)
            System.out.println("Food added successfully");
        else
            System.out.println("Food item couldn't be added");
    }

    public static void searchFoodItems(RestaurantDatabaseSystem rds) {
        while (true) {
            System.out.println("""
                    Food Item Searching Options:\s
                    1) By Name
                    2) By Name in a Given Restaurant
                    3) By Category
                    4) By Category in a Given Restaurant\s
                    5) By Price Range
                    6) By Price Range in a Given Restaurant
                    7) Costliest Food Item(s) on the Menu in a Given Restaurant
                    8) List of Restaurants and Total Food Item on the Menu
                    9) Back to Main Menu""");
            int choice;
            choice = sc.nextInt();
            sc.nextLine();
            switch (choice) {
                case 1: {
                    System.out.println("Enter food name: ");
                    String fdName = sc.nextLine();
                    List<Food> foodList = rds.searchFoodByName(fdName);
                    if (!foodList.isEmpty()) {
                        System.out.println("Foods that matches your search are: ");
                        for (Food fd : foodList) {
                            fd.showDetails();
                        }
                    } else
                        System.out.println("No such food item with this name");
                    break;
                }
                case 2: {
                    System.out.println("Enter food item name");
                    String foodName = sc.nextLine();
                    System.out.println("Enter restaurant name");
                    String restaurantName = sc.nextLine().trim();
                    List<Food> foodList = rds.searchFoodInRestaurant(foodName, restaurantName);
                    if (!foodList.isEmpty()) {
                        System.out.println("Foods that matches your search on the menu of " + restaurantName + " are:");
                        for (Food fd : foodList) {
                            fd.showDetails();
                        }
                    } else
                        System.out.println("No such food item with this name on the menu of this restaurant");
                    break;
                }
                case 3: {
                    System.out.println("Enter category name: ");
                    String category = sc.nextLine().trim();
                    List<Food> foodList = rds.searchFoodByCategory(category);
                    if (!foodList.isEmpty()) {
                        System.out.println("Foods that matches your searched category are:");
                        for (Food fd : foodList) {
                            fd.showDetails();
                        }
                    } else
                        System.out.println("No such food item with this category");
                    break;
                }
                case 4: {
                    System.out.println("Enter category name: ");
                    String category = sc.nextLine().trim();
                    System.out.println("Enter restaurant name: ");
                    String restaurantName = sc.nextLine().trim();
                    List<Food> foodList = rds.searchCategoryInRestaurant(restaurantName, category);
                    if (!foodList.isEmpty()) {
                        System.out.println("Foods that matches your searched category on the menu of " + restaurantName + " are:");
                        for (Food fd : foodList) {
                            fd.showDetails();
                        }
                    } else
                        System.out.println("No such food item with this category on the menu of the restaurant");
                    break;
                }
                case 5: {
                    System.out.println("Enter the range: ");
                    double price1 = sc.nextDouble();
                    sc.nextLine();
                    double price2 = sc.nextDouble();
                    sc.nextLine();
                    List<Food> foodList = rds.byPriceRange(price1, price2);
                    if (!foodList.isEmpty()) {
                        System.out.println("Foods that matches your searched price range are:");
                        for (Food fd : foodList) {
                            fd.showDetails();
                        }
                    } else
                        System.out.println("No such food items with this price range");
                    break;
                }
                case 6: {
                    System.out.println("Enter the range: ");
                    double price1 = Double.parseDouble(sc.next());
                    sc.nextLine();
                    double price2 = Double.parseDouble(sc.next());
                    sc.nextLine();
                    System.out.println("Enter restaurant name: ");
                    String restName = sc.nextLine().trim();
                    List<Food> foodList = rds.byPriceRangeInRestaurant(restName, price1, price2);
                    if (!foodList.isEmpty()) {
                        System.out.println("Foods that matches your searched price range on the menu of " + restName + " are:");
                        for (Food fd : foodList) {
                            fd.showDetails();
                        }
                    } else
                        System.out.println("No such food items with this price range on the menu of this restaurant");
                    break;
                }
                case 7: {
                    System.out.println("Enter the restaurant name: ");
                    String restName = sc.nextLine().trim();
                    List<Food> foodList = rds.costliestFoodItems(restName);
                    if (!foodList.isEmpty()) {
                        System.out.println("Costliest food items on the menu of " + restName + " are:");
                        for (Food fd : foodList) {
                            fd.showDetails();
                        }
                    } else
                        System.out.println("No such Restaurant with this name");
                    break;
                }
                case 8: {
                    Map<String, Integer> totalFoodsInRestaurants = rds.showTotalFoodCount();
                    System.out.println("Total Food Items on the Menu for every restaurant:");
                    for (Map.Entry<String, Integer> entry : totalFoodsInRestaurants.entrySet()) {
                        System.out.println(entry.getKey() + ": " + entry.getValue());
                    }
                    break;
                }
                case 9: {
                    return;
                }
                default: {
                    System.out.println("Invalid choice. Your choice must be between 1-9 ");
                }
            }
        }

    }

    private static void searchRestaurants(RestaurantDatabaseSystem rds) {
        while (true) {
            System.out.println("""
                    Restaurant Searching Options:
                    1) By Name
                    2) By Score
                    3) By Category
                    4) By Price
                    5) By Zip Code
                    6) Different Category Wise List of Restaurants
                    7) Back to Main Menu""");
            int choice = sc.nextInt();
            sc.nextLine();
            switch (choice) {
                case 1: {
                    System.out.println("Enter restaurant Name to search");
                    String resName = sc.nextLine().trim();
                    List<Restaurant> restaurantList = rds.searchRestaurantByName(resName);
                    if (restaurantList.isEmpty()) {
                        System.out.println("No such restaurant with this name");
                    } else {
                        System.out.println("Restaurant(s) that matches your searched name are:");
                        for (Restaurant rst : restaurantList) {
                            rst.showDetails();
                        }
                    }
                    break;
                }
                case 2: {
                    System.out.println("Enter score range: ");
                    double scr1 = Double.parseDouble(sc.next());
                    sc.nextLine();
                    double scr2 = Double.parseDouble(sc.next());
                    sc.nextLine();
                    List<Restaurant> restaurantList = rds.searchRestaurantByScore(scr1, scr2);
                    if (!restaurantList.isEmpty()) {
                        System.out.println("Restaurant(s) that matches your searched score range are:");
                        for (Restaurant rst : restaurantList) {
                            rst.showDetails();
                        }
                    } else
                        System.out.println("No such restaurant with this score range");
                    break;
                }
                case 3: {
                    System.out.println("Enter category name:");
                    String category = sc.nextLine().trim();
                    List<Restaurant> restaurants = rds.searchRestaurantByCategory(category);
                    if (!restaurants.isEmpty()) {
                        System.out.println("Restaurant(s) that matches your given category are:");
                        for (Restaurant rst : restaurants) {
                            rst.showDetails();
                        }
                    } else
                        System.out.println("No such restaurant with this category");
                    break;
                }
                case 4: {
                    System.out.println("Enter your preferred price: ");
                    String price = sc.nextLine().trim();
                    List<Restaurant> restaurants = rds.searchRestaurantByPrice(price);
                    if (!restaurants.isEmpty()) {
                        System.out.println("Restaurant(s) that matches your given price are:");
                        for (Restaurant rst : restaurants) {
                            rst.showDetails();
                        }
                    } else
                        System.out.println("No such restaurant with this price");
                    break;
                }
                case 5: {
                    System.out.println("Enter the zip code: ");
                    String zipCode = sc.nextLine().trim();
                    Restaurant rst = rds.searchRestaurantByZipCode(zipCode);
                    if (rst != null) {
                        System.out.println("Restaurant that matches your searched zip code is:");
                        rst.showDetails();
                    } else
                        System.out.println("No such restaurants with this zip code");
                    break;
                }
                case 6: {
                    Set <String> categorySet = rds.getAllCategories();
                    System.out.println("Here is a category based restaurants list for you:");
                    for (String category : categorySet) {
                        List<Restaurant> restaurantList = rds.searchRestaurantByCategory(category);

                        if (!restaurantList.isEmpty()) {

                            System.out.print(category + ": ");
                            for (int i = 0; i < restaurantList.size() - 1; i++) {
                                System.out.print(restaurantList.get(i).getRestaurantName() + ",");
                            }
                            System.out.println(restaurantList.get(restaurantList.size() - 1).getRestaurantName());
                        }
                    }
                    break;
                }
                case 7: {
                    return;
                }
                default: {
                    System.out.println("Invalid choice. Your choice must be between 1-7 ");
                }
            }
        }
    }
}