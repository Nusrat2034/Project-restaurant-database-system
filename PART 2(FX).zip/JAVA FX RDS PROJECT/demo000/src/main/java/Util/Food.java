package Util;

public class Food {
    private String foodName;
    private int restaurantId;
    private String category;
    private double price;
    private int quantity;

    public Food(int restaurantId,String category, String foodName, double price){
        this.restaurantId = restaurantId;
        this.category = category;
        this.foodName = foodName;
        this.price = price;
    }

    public Food(int restaurantId,String foodName,  int quantity) {
        this.foodName = foodName;
        this.restaurantId = restaurantId;
        this.quantity = quantity;
    }

    public Food(String foodName, String category, double price) {
        this.foodName = foodName;
        this.category = category;
        this.price = price;
    }

    public int getQuantity() {
        return quantity;
    }
    public String getMenuString()
    {
        StringBuilder sb = new StringBuilder();

        sb.append(foodName).append(",");
        sb.append(category).append(",");
        sb.append(price);
        return sb.toString();
    }
    public String getOrderString()
    {
        StringBuilder sb = new StringBuilder();

        sb.append(restaurantId).append(",");
        sb.append(foodName).append(",");
        sb.append(quantity);
        return sb.toString();
    }
    void setFoodName(String foodName1){
        this.foodName = foodName1;
    }
    void setRestaurantId(int restaurantId1){
        this.restaurantId = restaurantId1;
    }
    void setCategory(String category1){
        this.category = category1;
    }
    void setPrice(double price1){
        this.price = price1;
    }
    public String getFoodName(){
        return foodName;
    }
    public String getCategory(){
        return category;
    }
    public int getRestaurantId(){
        return restaurantId;
    }
    public double getPrice(){
        return price;
    }
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();

        sb.append(restaurantId).append(",");
        sb.append(category).append(",");
        sb.append(foodName).append(",");
        sb.append(price);
        return sb.toString();
    }
    public void showDetails()
    {
        System.out.println("Restaurant Id: "+ restaurantId+"   Food name:"+ foodName + "     Category:"+ category + "     Price:" + price);
    }
}
