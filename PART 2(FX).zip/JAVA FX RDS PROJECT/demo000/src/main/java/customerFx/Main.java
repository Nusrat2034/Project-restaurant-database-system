package customerFx;

import Util.Food;
import Util.Restaurant;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.ArrayList;

public class Main extends Application {

    Stage stage;
    Stage window;
    @Override
    public void start(Stage primaryStage) throws Exception{
        stage = primaryStage;
        window = primaryStage;
        showLoginPage();
        //showViewerMenu();
    }

    public void showMainMenu() throws IOException
    {
        Image backgroundImage = new Image(getClass().getResourceAsStream("/assets/menu.jpg"));
        ImageView backgroundImageView = new ImageView(backgroundImage);
        backgroundImageView.setFitWidth(555);
        backgroundImageView.setFitHeight(690);
        backgroundImageView.setPreserveRatio(false);

        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("mainmenu.fxml"));
        Parent root = loader.load();

        StackPane stackPane = new StackPane(backgroundImageView, root);

        MainmenuController controller = loader.getController();
        controller.setMain(this);

        stage.setTitle("Main Menu");
        stage.setScene(new Scene(stackPane, 555, 690));
        stage.show();
    }

    public void showLoginPage() throws Exception {

        Image backgroundImage = new Image(getClass().getResourceAsStream("/assets/login.jpg"));
        ImageView backgroundImageView = new ImageView(backgroundImage);
        backgroundImageView.setFitWidth(800);
        backgroundImageView.setFitHeight(600);
        backgroundImageView.setPreserveRatio(false);

        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("login.fxml"));
        Parent root = loader.load();

        StackPane stackPane = new StackPane(backgroundImageView, root);

        LoginController controller = loader.getController();
        controller.setMain(this);

        stage.setTitle("Log In");
        stage.setScene(new Scene(stackPane, 800, 600));
        stage.show();

    }

    public void showViewerMenu() throws Exception {

        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("viewermenu.fxml"));
        Parent root = loader.load();

        ViewerMenuController controller = loader.getController();
        controller.setMain(this);

        stage.setTitle("Viewer Menu");
        stage.setScene(new Scene(root, 917, 623));
        stage.show();
    }
    public void showRestaurant() throws Exception {
        Image backgroundImage = new Image(getClass().getResourceAsStream("/assets/boho.jpg"));
        ImageView backgroundImageView = new ImageView(backgroundImage);
        backgroundImageView.setFitWidth(845);
        backgroundImageView.setFitHeight(600);
        backgroundImageView.setPreserveRatio(false);

        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("restaurant.fxml"));
        Parent root = loader.load();

        StackPane stackPane = new StackPane(backgroundImageView, root);
        RestaurantController controller = loader.getController();
        controller.setMain(this);

        stage.setTitle("Restaurant Page");
        stage.setScene(new Scene(stackPane, 845, 600));
        stage.show();
    }

    public void showSearch() throws IOException {
        Image backgroundImage = new Image(getClass().getResourceAsStream("/assets/food.jpg"));
        ImageView backgroundImageView = new ImageView(backgroundImage);
        backgroundImageView.setFitWidth(1000);
        backgroundImageView.setFitHeight(620);
        backgroundImageView.setPreserveRatio(false);

        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("searchfood.fxml"));
       // System.out.println("loaded");
        Parent root = loader.load();
        StackPane stackPane = new StackPane(backgroundImageView, root);

       // System.out.println("loader");

        SearchFoodController controller = loader.getController();
        controller.setMain(this);

        stage.setTitle("Search Food");

        stage.setScene(new Scene(stackPane, 1000, 620));
        stage.show();
    }


    public static void main(String[] args) {
        launch(args);
    }
}