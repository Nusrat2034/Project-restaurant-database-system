package customerFx;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

public class MainmenuController {
    public Button viewRes;
    public Button viewFood;
    private Main main;
    @FXML
    private Button backButton;

    public void setMain(Main main) {
        this.main = main;
    }

    public void viewRestaurant(ActionEvent actionEvent) {
        try{
            this.main.showViewerMenu();
        }
        catch(Exception e)
        {
            e.printStackTrace();;
        }
    }

    public void viewFoods(ActionEvent actionEvent) {
        try{
            this.main.showSearch();
        }
        catch(Exception e)
        {
            e.printStackTrace();;
        }
    }
}
