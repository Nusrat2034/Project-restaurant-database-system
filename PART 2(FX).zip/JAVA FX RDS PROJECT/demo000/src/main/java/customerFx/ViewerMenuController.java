package customerFx;

import Client.Client;
import Util.Restaurant;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
//import network.Client;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ViewerMenuController {

    private static ObservableList<Restaurant> data;
    public Button viewerMenuViewAllCarButton;
    public Button viewerMenuBackButton;
    public Button searchWithName;
    public TextField NameField;
    public Button searchForFood;
    public Button searchWithCategory;
    public TextField CategoryField;
    public Button SearchWithScore;
    public TextField ScoreField1;
    public TextField ScoreField2;
    public TextField PriceField;
    public Button SearchWithPrice;
    @FXML
    private TableView<Restaurant> viewerMenuTable;
    @FXML
    private TableColumn<Restaurant, Integer> viewerMenuTableResId;
    @FXML
    private TableColumn<Restaurant, String> viewerMenuTableResName;
    @FXML
    private TableColumn<Restaurant, Double> viewerMenuTableScore;
    @FXML
    private TableColumn<Restaurant, String> viewerMenuTableZipCode;
    @FXML
    private TableColumn<Restaurant, String> viewerMenuTablePrice;
    @FXML
    private TableColumn<Restaurant, String> viewerMenuTableCategory1;
    @FXML
    private TableColumn<Restaurant, String> viewerMenuTableCategory2;
    @FXML
    private TableColumn<Restaurant, String> viewerMenuTableCategory3;
    @FXML
    private Label viewerMenuTitle;

    private Main main;

    public void setMain(Main main) {
        this.main = main;
    }

    private void loadData(String dataString)
    {
        String[] inputs = dataString.split(",");
        List<Restaurant> rstList = new ArrayList<>();

        for (int i = 0; i < inputs.length / 8; i++)
        {
            Restaurant temp = new Restaurant(Integer.parseInt(inputs[i * 8]), inputs[i * 8 + 1], Double.parseDouble(inputs[i * 8 + 2]),
                    inputs[i * 8 + 3], inputs[i * 8 + 4] , inputs[i * 8 + 5], inputs[i *8 + 6] , inputs[i *8 +7] );
            rstList.add(temp);
        }
        data = FXCollections.observableArrayList(rstList);
        System.out.println(data);
    }


    public void backPressed(ActionEvent actionEvent) {
        try {
            main.showMainMenu();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public void searchForFood(ActionEvent actionEvent) {
        try{
            main.showSearch();
        }catch (Exception e)
        {
            e.printStackTrace();
        }
    }
    @FXML
    void initialize() throws IOException {

        viewerMenuTableResId.setCellValueFactory(new PropertyValueFactory<>("Id"));
        viewerMenuTableResName.setCellValueFactory(new PropertyValueFactory<>("restaurantName"));
        viewerMenuTablePrice.setCellValueFactory(new PropertyValueFactory<>("price"));
        viewerMenuTableScore.setCellValueFactory(new PropertyValueFactory<>("score"));
        viewerMenuTableZipCode.setCellValueFactory(new PropertyValueFactory<>("zipCode"));
        viewerMenuTableCategory1.setCellValueFactory(new PropertyValueFactory<>("category1"));
        viewerMenuTableCategory2.setCellValueFactory(new PropertyValueFactory<>("category2"));
        viewerMenuTableCategory3.setCellValueFactory(new PropertyValueFactory<>("category3"));
        //viewAllRestaurants(null);
    }

    public void viewAllRestaurants(ActionEvent actionEvent) throws IOException
    {
        String toBeWritten = "viewrestaurant,1";
        System.out.println(toBeWritten);
        String response = Client.getClientThread().query(toBeWritten);
        System.out.println(response.length());

//        data = FXCollections.observableArrayList(
//                new Restaurant(1, "kfc", 4.5, "$$", "123456"),
//                new Restaurant(1, "kfc", 4.5, "$$", "123456"),
//                new Restaurant(1, "kfc", 4.5, "$$", "123456")
//        );

        loadData(response);

        viewerMenuTable.setEditable(true);
        viewerMenuTable.setItems(data);
    }

    public void searchWithName(ActionEvent actionEvent) throws IOException {

        if (NameField.getText().isBlank()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Please enter a restaurant name:");
            alert.showAndWait();
            return;
        }

        String toBeWritten =  "viewrestaurant" + "," + 2;

        toBeWritten = toBeWritten + "," + NameField.getText();
        System.out.println(toBeWritten);
        String response = Client.getClientThread().query(toBeWritten);
        System.out.println(response.length());

        if (response.equals("No such restaurant with this name")) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("No such restaurant with this name");
            alert.showAndWait();
            return;
        }

        loadData(response);

        viewerMenuTable.setEditable(true);
        viewerMenuTable.setItems(data);

    }



    public void searchWithCategory(ActionEvent actionEvent) throws IOException {
        if (CategoryField.getText().isBlank()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Please enter a restaurant name:");
            alert.showAndWait();
            return;
        }

        String toBeWritten =  "viewrestaurant" + "," + 3;
        toBeWritten = toBeWritten + "," + CategoryField.getText();
        System.out.println(toBeWritten);
        String response = Client.getClientThread().query(toBeWritten);
        System.out.println(response.length());

        if (response.equals("No such restaurant with this category")) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("No such restaurant with this Category");
            alert.showAndWait();
            return;
        }

        loadData(response);

        viewerMenuTable.setEditable(true);
        viewerMenuTable.setItems(data);

    }

    public void SearchWithScore(ActionEvent actionEvent) throws IOException {
        if (ScoreField1.getText().isBlank()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Please enter a restaurant Score:");
            alert.showAndWait();
            return;
        }

        String toBeWritten =  "viewrestaurant" + "," + 4;
        toBeWritten = toBeWritten + "," + ScoreField1.getText() +"," + ScoreField2.getText();
        System.out.println(toBeWritten);
        String response = Client.getClientThread().query(toBeWritten);
        System.out.println(response.length());

        if (response.equals("No such restaurant with this score")) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("No such restaurant with this score");
            alert.showAndWait();
            return;
        }

        loadData(response);

        viewerMenuTable.setEditable(true);
        viewerMenuTable.setItems(data);
    }

    public void SearchWithPrice(ActionEvent actionEvent) throws IOException {
        if (PriceField.getText().isBlank()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Please enter a restaurant Price:");
            alert.showAndWait();
            return;
        }

        String toBeWritten =  "viewrestaurant" + "," + 5;
        toBeWritten = toBeWritten + "," + PriceField.getText() ;
        System.out.println(toBeWritten);
        String response = Client.getClientThread().query(toBeWritten);
        System.out.println(response.length());

        if (response.equals("No such restaurant with this price")) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("No such restaurant with this price");
            alert.showAndWait();
            return;
        }

        loadData(response);

        viewerMenuTable.setEditable(true);
        viewerMenuTable.setItems(data);
    }
}