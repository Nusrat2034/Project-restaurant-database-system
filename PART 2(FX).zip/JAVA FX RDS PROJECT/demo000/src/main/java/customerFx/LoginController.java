package customerFx;

import Client.Client;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Alert;
//import network.Client;

import java.util.HashMap;


public class LoginController {

    public Button loginButton1;
    public TextField usernameText1;
    @FXML
    private TextField usernameText;

    @FXML
    private PasswordField passwordText;

    @FXML
    private Button resetButton;

    @FXML
    private Button loginButton;

    private Main main;

//    private Client clientThread;

//    public void setClientThread(Client clientThread) {
//        this.clientThread = clientThread;
//    }

    @FXML
    void loginAction(ActionEvent event) throws Exception {


        if (usernameText.getText().isBlank()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Please enter an user name:");
            alert.showAndWait();
            return;
        }
        if(passwordText.getText().isBlank())
        {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Please enter a password:");
            alert.showAndWait();
            return;
        }

        String resName = usernameText.getText();
        String toBeWritten = "verifylogin" + "," + resName + "," + passwordText.getText();
        System.out.println(toBeWritten);
        String response = Client.getClientThread().query(toBeWritten);
        System.out.println(response.length());
        if(response.equalsIgnoreCase("valid")) {
            this.main.showRestaurant();
        }
        else if(response.equalsIgnoreCase("no restaurant"))
        {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("No such restaurant with this name");
            alert.showAndWait();
            return;
        }

        else if(response.equalsIgnoreCase("invalid"))
        {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Incorrect Password");
            alert.showAndWait();
            return;
        }

    }

    void setMain(Main main) {
        this.main = main;
    }

    public void loginActionCustomer(ActionEvent actionEvent) throws Exception {

        this.main.showMainMenu();
    }
}