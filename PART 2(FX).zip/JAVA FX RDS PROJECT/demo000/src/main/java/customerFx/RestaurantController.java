package customerFx;

import Client.Client;
import Util.Food;
import Util.Restaurant;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class RestaurantController {
    private static ObservableList<Food> data;
    private static ObservableList<Food> menu;
    private static ObservableList<Restaurant> resData;
    @FXML
    public TableView <Food> viewerMenuTable;
    public TableColumn<Food, String> viewerMenuTableFoodName;
    public TableColumn<Food, Integer> viewerMenuTableResId;
    public TableColumn<Food, Integer> viewerMenuTableQuantity;

    public Button viewOrders;
    public Label restTitle;
    public TableView <Restaurant>RestaurantTable;
    public TableColumn <Restaurant, String> resName;
    public TableColumn<Restaurant, Integer> ResId;
    public TableColumn <Restaurant, String> resPrice;
    public TableColumn <Restaurant,String> resZip;
    public TableColumn <Restaurant,String> resCategory;
    public TableColumn <Restaurant, Double>resScore;
    public TableColumn<Restaurant, String> resCategory2;
    public TableColumn<Restaurant, String> resCategory3;
    public Label viewerMenuTitle;
    public Label viewerMenuTitle1;

    public TableView <Food> MenuTable;
    public TableColumn<Food, String> menuTableFoodName;
    public TableColumn<Food, Double> menuTablePrice;
    public TableColumn<Food, String> menuTableCategory;
    private Main main;

    public void setMain(Main main) {
        this.main = main;
    }

    private void loadResDataForRestaurantTable(ActionEvent actionEvent) throws IOException {
        String toBeWritten = "viewRest";
        String response = Client.getClientThread().query(toBeWritten);
        System.out.println(response.length());

        List<Restaurant> restaurantList = new ArrayList<>();
        String[] inputs = response.split(",");

        for (int i = 0; i < inputs.length / 8; i++) {
            Restaurant temp = new Restaurant(
                    Integer.parseInt(inputs[i * 8]),
                    inputs[i * 8 + 1],
                    Double.parseDouble(inputs[i * 8 + 2]),
                    inputs[i * 8 + 3],
                    inputs[i * 8 + 4],
                    inputs[i * 8 + 5],
                    inputs[i * 8 + 6],
                    inputs[i * 8 + 7]
            );
            restaurantList.add(temp);
        }

        resData = FXCollections.observableArrayList(restaurantList);
        RestaurantTable.setItems(resData);
    }

    private void loadMenu(String dataString)
    {
        String[] inputs = dataString.split(",");
        List<Food> foodList = new ArrayList<>();

        for (int i = 0; i < inputs.length / 3; i++) {
            Food temp = new Food(inputs[i * 3], inputs[i * 3 + 1], Double.parseDouble(inputs[i * 3 + 2]));
            foodList.add(temp);
        }
        menu = FXCollections.observableArrayList(foodList);
        System.out.println(menu);
    }

    private void loadData(String dataString) {
        String[] inputs = dataString.split(",");
        List<Food> foodList = new ArrayList<>();

        for (int i = 0; i < inputs.length / 3; i++) {
            Food temp = new Food(Integer.parseInt(inputs[i * 3]), inputs[i * 3 + 1], Integer.parseInt(inputs[i * 3 + 2]));
            foodList.add(temp);
        }
        data = FXCollections.observableArrayList(foodList);
        System.out.println(data);
    }

    @FXML
    void initialize() throws IOException {

        viewerMenuTableFoodName.setCellValueFactory(new PropertyValueFactory<>("foodName"));
        viewerMenuTableResId.setCellValueFactory(new PropertyValueFactory<>("restaurantId"));
        viewerMenuTableQuantity.setCellValueFactory(new PropertyValueFactory<>("quantity"));

        resName.setCellValueFactory(new PropertyValueFactory<>("restaurantName"));
        ResId.setCellValueFactory(new PropertyValueFactory<>("Id"));
        resPrice.setCellValueFactory(new PropertyValueFactory<>("price"));
        resZip.setCellValueFactory(new PropertyValueFactory<>("zipCode"));
        resCategory.setCellValueFactory(new PropertyValueFactory<>("category1"));
        resScore.setCellValueFactory(new PropertyValueFactory<>("score"));
        resCategory2.setCellValueFactory(new PropertyValueFactory<>("category2"));
        resCategory3.setCellValueFactory(new PropertyValueFactory<>("category3"));

        menuTableFoodName.setCellValueFactory(new PropertyValueFactory<>("foodName"));
        menuTableCategory.setCellValueFactory(new PropertyValueFactory<>("category"));
        menuTablePrice.setCellValueFactory(new PropertyValueFactory<>("price"));

        loadResDataForRestaurantTable(null);

        viewMenu();
    }

    public void viewMenu() throws IOException {
        String toBeWritten = "viewmenu";
        System.out.println(toBeWritten);
        String response = Client.getClientThread().query(toBeWritten);
        System.out.println(response.length());

        loadMenu(response);
        MenuTable.setEditable(true);
        MenuTable.setItems(menu);
    }
    public void viewOrders(ActionEvent actionEvent) throws IOException {
        String toBeWritten = "viewOrder,1";
        System.out.println(toBeWritten);
        String response = Client.getClientThread().query(toBeWritten);
        System.out.println(response.length());

//        data = FXCollections.observableArrayList(
//                new Food(1,"Chicken", "Burger", 4.4),
//                new Food(1,"Chicken", "Burger", 4.4),
//                new Food(1,"Chicken", "Burger", 4.4)
//        );
        loadData(response);
        viewerMenuTable.setEditable(true);
        viewerMenuTable.setItems(data);
    }
}
