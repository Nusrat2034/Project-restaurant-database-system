package customerFx;

import Client.Client;
import Util.Food;
import javafx.animation.PauseTransition;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.util.Duration;
//import network.Client;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


public class SearchFoodController {
    private static ObservableList<Food> data;
    public TableView<Food> viewerMenuTable;
    public Label viewerMenuTitle;
    public Button viewerMenuBackButton;
    public Button SearchByName;
    public Button searchWithCategory;
    public Button searchWithPrice;
    public TableColumn<Food, String> viewerMenuTableFoodName;
    public TableColumn<Food, Integer> viewerMenuTableResId;
    public TableColumn<Food, Double> viewerMenuTablePrice;
    public TableColumn<Food, String> viewerMenuTableCategory;
    public TextField NameTextField;
    public TextField CategoryTextField;
    public TextField LPriceTextField;
    public TextField RpriceTextField;
    public Button searchFoodNameInRest;
    public TextField RestNameField;
    public TextField FoodNameField;
    public TextField RestNameField1;
    public TextField foodCategoryNameField;
    public Button searchWithCatInRest;
    public TextField quantityField;
    public TextField RestNameField11;
    public TextField priceField1;
    public TextField priceField2;
    public Button searchByPriceRest;
    public Button orderFood;
    public TextField CostliestItemField;
    public Button costliesttems;
    public Button costliesItems;
    public TextField viewMenuField;
    public Button viewMenu;
    private Main main;
    @FXML
    private Button backButton;

    public void setMain(Main main) {
        this.main = main;
    }

    @FXML
    void backPressed(ActionEvent event) {
        try {
            main.showMainMenu();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadData(String dataString) {
        String[] inputs = dataString.split(",");
        List<Food> foodList = new ArrayList<>();

        for (int i = 0; i < inputs.length / 4; i++) {
            Food temp = new Food(Integer.parseInt(inputs[i * 4]), inputs[i * 4 + 1], inputs[i * 4 + 2], Double.parseDouble(inputs[i * 4 + 3]));
            foodList.add(temp);
        }
        data = FXCollections.observableArrayList(foodList);
        System.out.println(data);
    }

    @FXML
    void initialize() throws IOException {

        viewerMenuTableFoodName.setCellValueFactory(new PropertyValueFactory<>("foodName"));
        viewerMenuTableResId.setCellValueFactory(new PropertyValueFactory<>("restaurantId"));
        viewerMenuTablePrice.setCellValueFactory(new PropertyValueFactory<>("price"));
        viewerMenuTableCategory.setCellValueFactory(new PropertyValueFactory<>("category"));

        viewAllFood(null);
    }

    public void searchWithPrice(ActionEvent actionEvent) throws IOException {
        if (LPriceTextField.getText().isBlank() || RpriceTextField.getText().isBlank()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Please enter a food price range:");
            alert.showAndWait();
            return;
        }
        String toBeWritten = "viewfood" + "," + 4;
        toBeWritten = toBeWritten + "," + LPriceTextField.getText() + "," + RpriceTextField.getText();
        System.out.println(toBeWritten);
        String response = Client.getClientThread().query(toBeWritten);
        System.out.println(response.length());

        if (response.equals("No such food item with this price range")) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("No such food item with this price range");
            alert.showAndWait();
            return;
        }

        loadData(response);

        viewerMenuTable.setEditable(true);
        viewerMenuTable.setItems(data);
    }

    public void searchWithCategory(ActionEvent actionEvent) throws IOException {
        if (CategoryTextField.getText().isBlank()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Please enter a food category name:");
            alert.showAndWait();
            return;
        }
        String toBeWritten = "viewfood" + "," + 3;
        toBeWritten = toBeWritten + "," + CategoryTextField.getText();
        System.out.println(toBeWritten);
        String response = Client.getClientThread().query(toBeWritten);
        System.out.println(response.length());

        if (response.equals("No such food item with this category")) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("No such food item with this category");
            alert.showAndWait();
            return;
        }

        loadData(response);

        viewerMenuTable.setEditable(true);
        viewerMenuTable.setItems(data);
    }

    public void searchWithName(ActionEvent actionEvent) throws IOException {
        if (NameTextField.getText().isBlank()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Please enter a food item name:");
            alert.showAndWait();
            return;
        }

        String toBeWritten = "viewfood" + "," + 2;
        toBeWritten = toBeWritten + "," + NameTextField.getText();
        System.out.println(toBeWritten);
        String response = Client.getClientThread().query(toBeWritten);
        System.out.println(response.length());

        if (response.equals("No such food item with this name")) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("No such food item with this name");
            alert.showAndWait();
            return;
        }

        loadData(response);

        viewerMenuTable.setEditable(true);
        viewerMenuTable.setItems(data);
    }

    public void viewAllFood(ActionEvent actionEvent) throws IOException {
        String toBeWritten = "viewfood,1";
        System.out.println(toBeWritten);
        String response = Client.getClientThread().query(toBeWritten);
        System.out.println(response.length());

//        data = FXCollections.observableArrayList(
//                new Food(1,"Chicken", "Burger", 4.4),
//                new Food(1,"Chicken", "Burger", 4.4),
//                new Food(1,"Chicken", "Burger", 4.4)
//        );
        loadData(response);
        viewerMenuTable.setEditable(true);
        viewerMenuTable.setItems(data);
    }

    public void searchWithNameInRest(ActionEvent actionEvent) throws IOException {
        if (FoodNameField.getText().isBlank()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Please enter a food item name:");
            alert.showAndWait();
            return;
        }
        if (RestNameField.getText().isBlank()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Please enter a Restaurant name:");
            alert.showAndWait();
            return;
        }

        String toBeWritten = "viewfood" + "," + 5;
        toBeWritten = toBeWritten + "," + RestNameField.getText() + "," + FoodNameField.getText();
        System.out.println(toBeWritten);
        String response = Client.getClientThread().query(toBeWritten);
        System.out.println(response.length());

        if (response.equals("No such food item with this name")) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("No such food item with this name in this Restaurant");
            alert.showAndWait();
            return;
        }
        loadData(response);
        viewerMenuTable.setEditable(true);
        viewerMenuTable.setItems(data);
    }

    public void searchWithCatInRest(ActionEvent actionEvent) throws IOException {
        if (foodCategoryNameField.getText().isBlank()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Please enter a food category name:");
            alert.showAndWait();
            return;
        }
        if (RestNameField1.getText().isBlank()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Please enter a Restaurant name:");
            alert.showAndWait();
            return;
        }

        String toBeWritten = "viewfood" + "," + 6;
        toBeWritten = toBeWritten + "," + RestNameField1.getText() + "," + foodCategoryNameField.getText();
        System.out.println(toBeWritten);
        String response = Client.getClientThread().query(toBeWritten);
        System.out.println(response.length());

        if (response.equals("No such food item with this category")) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("No such food item with this category in this Restaurant");
            alert.showAndWait();
            return;
        }
        loadData(response);
        viewerMenuTable.setEditable(true);
        viewerMenuTable.setItems(data);

    }

    public void orderThisFood(ActionEvent actionEvent) throws IOException {
        Food selectedFood = viewerMenuTable.getSelectionModel().getSelectedItem();
        int quantity = Integer.parseInt(quantityField.getText());


        String toBeWritten = "orderfood" + "," + selectedFood.getRestaurantId() + "," + selectedFood.getFoodName() + "," + quantity;

        String response = Client.getClientThread().query(toBeWritten);

        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("message.fxml"));
            Parent messageRoot = loader.load();
            Scene messageScene = new Scene(messageRoot);

            Stage messageStage = new Stage();
            messageStage.setTitle("Order Placed Successfully");
            messageStage.setScene(messageScene);

            messageStage.show();
            PauseTransition delay = new PauseTransition(Duration.seconds(3));
            delay.setOnFinished(event -> messageStage.close());
            delay.play();
        } catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    public void SearchByPriceInRest(ActionEvent actionEvent) throws IOException {
        if (priceField1.getText().isBlank() ||priceField1.getText().isBlank() ) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Please enter a food price range:");
            alert.showAndWait();
            return;
        }
        if (RestNameField11.getText().isBlank()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Please enter a Restaurant name:");
            alert.showAndWait();
            return;
        }

        String toBeWritten = "viewfood" + "," + 7;
        toBeWritten = toBeWritten + "," + RestNameField11.getText() + "," + priceField1.getText() + "," + priceField2.getText();
        System.out.println(toBeWritten);
        String response = Client.getClientThread().query(toBeWritten);
        System.out.println(response.length());

        if (response.equals("No such food item with this range")) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("No such food item with this price range in this Restaurant");
            alert.showAndWait();
            return;
        }
        loadData(response);
        viewerMenuTable.setEditable(true);
        viewerMenuTable.setItems(data);
    }

    public void costliestItems(ActionEvent actionEvent) throws IOException {
        if (CostliestItemField.getText().isBlank() ) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Please enter a restaurant name:");
            alert.showAndWait();
            return;
        }


        String toBeWritten = "viewfood,8";
        toBeWritten = toBeWritten + "," + CostliestItemField.getText();
        System.out.println(toBeWritten);
        String response = Client.getClientThread().query(toBeWritten);
        System.out.println(response.length());

        if (response.equals("No such restaurant")) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("No such restaurant with this name");
            alert.showAndWait();
            return;
        }
        loadData(response);
        viewerMenuTable.setEditable(true);
        viewerMenuTable.setItems(data);
    }

    public void viewrestaurantMenu(ActionEvent actionEvent) throws IOException {
        if (viewMenuField.getText().isBlank() ) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Please enter a restaurant name:");
            alert.showAndWait();
            return;
        }

        String toBeWritten = "viewfood,9";
        toBeWritten = toBeWritten + "," + viewMenuField.getText();
        System.out.println(toBeWritten);
        String response = Client.getClientThread().query(toBeWritten);
        System.out.println(response.length());

        if (response.equals("No such restaurant")) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("No such restaurant with this name");
            alert.showAndWait();
            return;
        }
        loadData(response);
        viewerMenuTable.setEditable(true);
        viewerMenuTable.setItems(data);

    }
}
