package customerFx;

public class MessageController {

}
