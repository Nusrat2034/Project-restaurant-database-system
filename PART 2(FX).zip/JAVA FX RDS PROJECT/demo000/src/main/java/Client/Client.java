package Client;

import Util.SocketWrapper;

import java.io.IOException;

public  class Client extends Thread {
    private static Client client;
    private static SocketWrapper socketWrapper;


    private Client() throws IOException {
        String serverAddress = "localhost";
        int serverPort = 5161;
        socketWrapper = new SocketWrapper(serverAddress, serverPort);
        start();
    }

    public static Client getClientThread() throws IOException {
        if (client == null) {
            client = new Client();
        }
        return client;
    }

    public String query(String queryString) throws IOException {

        socketWrapper.write(queryString);

        try {
            while (true) {
                String s = (String) socketWrapper.read();
                if (s != null) {
                    return s;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

}