module com.example.demo000 {
    requires javafx.controls;
    requires javafx.fxml;


    opens customerFx to javafx.fxml;
    opens Util;
    exports customerFx;
}