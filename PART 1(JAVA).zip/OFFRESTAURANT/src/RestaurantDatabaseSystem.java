import java.util.*;

public class RestaurantDatabaseSystem {
    private List <Restaurant> RDS= new ArrayList<>();
    public void addRestaurant( Restaurant r){
        RDS.add(r);
    }
    public Restaurant search11(String Name){
        for(Restaurant r:RDS){
            if((r.getName().toLowerCase()).contains(Name.toLowerCase())){
               return r;
            }
        }
        return null;
    }

    public List<Restaurant> search12(double a,double b){
        List<Restaurant>ans=new ArrayList<>();
        for(Restaurant r:RDS){
            if(r.getScore()>=a && r.getScore()<=b){
                ans.add(r);
            }
        }
        return ans;
    }
    public List<Restaurant> search13(String category) {
        List<Restaurant> ans = new ArrayList<>();
        for (Restaurant r : RDS) {
            for (String c : r.getCategory()) {
                if ((c.toLowerCase()).contains(category.toLowerCase())) {
                    ans.add(r);
                }
            }
        }
        return ans;
    }

    public List<Restaurant> search14(String price) {
        List<Restaurant>ans=new ArrayList<>();
        for(Restaurant r:RDS){
            if(r.getPrice().equalsIgnoreCase((price))){
                ans.add(r);
            }
        }
        return ans;
    }
    public List<Restaurant> search15(String zipcode) {
        List<Restaurant>ans=new ArrayList<>();
        for(Restaurant r:RDS){
            if(r.getZipCode().equalsIgnoreCase((zipcode))){
                ans.add(r);
            }
        }
        return ans;
    }
    public void search16() {
        Set<String> uniqueCategories = new HashSet<>();
        for (Restaurant r : RDS) {
            for (String c : r.getCategory()) {
                uniqueCategories.add(c);
            }
        }
        List<String> categoryList = new ArrayList<>(uniqueCategories);
        Map<String, List<String>> categoryToRestaurants = new HashMap<>();

        for (String category : categoryList) {
            List<Restaurant> restaurants = search13(category);
            if (!restaurants.isEmpty()) {
                List<String> restaurantNames = new ArrayList<>();
                for (Restaurant r : restaurants) {
                    restaurantNames.add(r.getName());
                }
                categoryToRestaurants.put(category, restaurantNames);
            }
        }

        for (String category : categoryToRestaurants.keySet()) {
            System.out.print(category + ": ");
            List<String> restaurantNames = categoryToRestaurants.get(category);
            for (int i = 0; i < restaurantNames.size(); i++) {
                System.out.print(restaurantNames.get(i));
                if (i < restaurantNames.size() - 1) {
                    System.out.print(", ");
                }
            }
            System.out.println();
        }
    }

    public List<Food> search21(String name) {
        List<Food> ans = new ArrayList<>();
        for (Restaurant r : RDS) {
            Food f = r.help21(name);
            if (f != null) {
                ans.add(f);
            }
        }
        return ans;
    }


    public Food search22(String restaurant_name,String food_name){
        for(Restaurant r:RDS){
            if((r.getName().toLowerCase()).contains(restaurant_name.toLowerCase())){
               return r.help21(food_name);
            }
        }
        return null;
    }
    public List<List<Food>> search23(String category){
        List<List<Food>>ans=new ArrayList<>();
        for(Restaurant r:RDS){
        List<Food> RL1=new ArrayList<>();
        RL1=r.help23(category);
        ans.add(RL1);
        }
        return ans;
    }

    public List<Food> search24(String name,String category){
        List<Food>ans=new ArrayList<>();
        for(Restaurant r:RDS){
            if((r.getName().toLowerCase()).contains(name.toLowerCase())) {
               ans=r.help23(category);
            }
        }
        return ans;
    }

    public List<List<Food>> search25(double a,double b){
        List<List<Food>>ans=new ArrayList<>();
        for(Restaurant r:RDS){
            List<Food> RL1=new ArrayList<>();
            RL1=r.help25(a,b);
            ans.add(RL1);
        }
        return ans;
    }

    public List<Food> search26(double a,double b,String name){
        List<Food>ans=new ArrayList<>();
        for(Restaurant r:RDS){
            if( (r.getName().toLowerCase()).contains(name.toLowerCase())) {
             ans=r.help25(a,b);
            }
        }
       return ans;
    }

    public Food search27(String name){
        for(Restaurant r:RDS){
            if((r.getName().toLowerCase()).contains(name.toLowerCase())){
                return r.CostlyFood();
            }
        }
        return null;
    }

        public Map<String, Integer> search28() {
            Map<String, Integer> restaurantData = new HashMap<>();
            for(Restaurant r:RDS){
                restaurantData.put(r.getName(), r.getTotalItem());
            }
            return restaurantData;
        }
    public void addmenu(Food f){
        for(Restaurant r:RDS){
            if(r.getID()==f.getRestaurant_ID()){
                r.addFood(f);
            }
        }
    }
    public void search3(Restaurant r){
        RDS.add(r);
    }

    public void  search4(String restaurant_name,Food f){
        for(Restaurant r:RDS){
            if(r.getName().equalsIgnoreCase(restaurant_name)){
                r.addFood(f);
                return;
            }
        }
        System.out.println("This restaurant doesn't exists in this database");
    }
    public boolean FoodPresent(String rname,Food f){
        for(Restaurant r:RDS){
            if(r.getName().equalsIgnoreCase(rname)){
                return r.isFoodPresent(f);
            }
        }
        return false;
    }
    public boolean ispresent(String name){
        for(Restaurant r:RDS){
            if(r.getName().equalsIgnoreCase(name)){
                return true;
            }
        }
        return false;
    }
    public void menu1(){
        System.out.println("Restaurant searching Option(1-7):");
        System.out.println("1) By Name");
        System.out.println("2) By Score");
        System.out.println("3) By Category");
        System.out.println("4) By Price");
        System.out.println("5) By Zip Code");
        System.out.println("6) Different Category Wise List of Restaurants");
        System.out.println("7) Back to main");
    }
    public void menu2(){
        System.out.println("Food Searching Options(1-9):");
        System.out.println("1) By Name");
        System.out.println("2) By Name in a Given Restaurant");
        System.out.println("3) By category");
        System.out.println("4) By Category in a Given Restaurant");
        System.out.println("5) By Price Range");
        System.out.println("6) By Price Range in a Given Restaurant");
        System.out.println("7) Costliest food items on the menu in a given Restaurant");
        System.out.println("8) List of Restaurants and Total food Item on the menu");
        System.out.println("9) Back to menu");
    }

    }

