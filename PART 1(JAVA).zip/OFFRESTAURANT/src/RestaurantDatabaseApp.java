import java.io.*;
import java.util.*;
public class RestaurantDatabaseApp {
    private static final String INPUT_RESTAURANT_NAME = "restaurant.txt";
    private static final String INPUT_MENU_NAME = "menu.txt";
    private static final String OUTPUT_RESTAURANT_NAME="restaurant.txt";
    private static final String OUTPUT_MENU_NAME="menu.txt";
    public static void main(String[] args) throws Exception {
                RestaurantDatabaseSystem rds = new RestaurantDatabaseSystem();
                try (BufferedReader rr = new BufferedReader(new FileReader(INPUT_RESTAURANT_NAME));
                     BufferedReader mr = new BufferedReader(new FileReader(INPUT_MENU_NAME))) {

                    // Read and process restaurant data
                    String line;
                    while ((line = rr.readLine()) != null) {
                        String[] parts = line.split(",",-1);
                        int id = Integer.parseInt(parts[0]);
                        String name = parts[1];
                        double score = Double.parseDouble(parts[2]);
                        String price = parts[3] ;
                        String zipCode = parts[4];
                        List<String>categories=new ArrayList<>();
                        for(int i=5;i< parts.length;i++){
                            categories.add(parts[i]);
                        }
                        Restaurant restaurant = new Restaurant(id, name, score, price, zipCode,categories);
                        rds.search3(restaurant);
                    }

                    // Read and process menu data
                    while ((line = mr.readLine()) != null) {
                        String[] parts = line.split(",");
                            int restaurantId = Integer.parseInt(parts[0]);
                            String category = parts[1];
                            String itemName = parts[2];
                            double itemPrice = Double.parseDouble(parts[3]);
                            Food food = new Food(restaurantId, category, itemName, itemPrice);
                            rds.addmenu(food);
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }

        Scanner scanner =new Scanner(System.in);
        while(true){
            System.out.println("Main Menu:");
            System.out.println("1) Search Restaurants");
            System.out.println("2) Search Food Items");
            System.out.println("3) Add Restaurant");
            System.out.println("4) Add food Item to the menu");
            System.out.println("5) Exit System");
            System.out.println("Enter your option(1-5):");
           int c= scanner.nextInt();
           scanner.nextLine();
            switch(c){
                case 1:{
                    boolean c1=true;
                    while(c1){
                        rds.menu1();
                        int m1= scanner.nextInt();
                        scanner.nextLine();
                        switch (m1){
                            case 1:{
                                System.out.println("Enter a restaurant name:");
                                String name=scanner.nextLine();
                                Restaurant r=rds.search11(name);
                                if(r!=null) {
                                    r.print();
                                }
                                else{
                                    System.out.println("No such restaurant with this name");
                                }
                                break;
                            }
                            case 2:{
                                System.out.println("Enter two numbers as range:");
                               double a= scanner.nextDouble();
                               double b= scanner.nextDouble();
                               List<Restaurant>rlist=new ArrayList<>();
                               rlist=rds.search12(a,b);
                               if(!rlist.isEmpty()){
                                   for(Restaurant r:rlist){
                                       r.print();
                                       System.out.println();
                                   }
                               }
                               else{
                                   System.out.println("No such restaurant with this range.");
                               }
                               break;
                            }
                            case 3:{
                                System.out.println("Enter category:");
                                String category=scanner.nextLine();
                                List<Restaurant>rlist=new ArrayList<>();
                                rlist=rds.search13(category);
                                if(!rlist.isEmpty()){
                                    for(Restaurant r:rlist){
                                        r.print();
                                        System.out.println();
                                    }
                                }
                                else{
                                    System.out.println("No such restaurant with this category.");
                                }
                                break;
                            }
                            case 4:{
                                System.out.println("Enter price:");
                                String price= scanner.nextLine();
                                List<Restaurant>rlist=new ArrayList<>();
                                rlist=rds.search14(price);
                                if(!rlist.isEmpty()){
                                    for(Restaurant r:rlist){
                                        r.print();
                                        System.out.println();
                                    }
                                }
                                else{
                                    System.out.println("No such restaurant with this price.");
                                }
                                break;
                            }
                            case 5:{
                                System.out.println("Enter Zip code");
                                String zipcode=scanner.nextLine();
                                List<Restaurant>rlist=new ArrayList<>();
                                rlist=rds.search15(zipcode);
                                if(!rlist.isEmpty()){
                                    for(Restaurant r:rlist){
                                        r.print();
                                        System.out.println();
                                    }
                                }
                                else{
                                    System.out.println("No such restaurant with this zipcode.");
                                }
                                break;
                            }
                            case 6:{
                                rds.search16();
                                break;
                            }
                            case 7:{
                             c1=false;
                            }
                            default:{
                                System.out.println("Wrong Option.");
                            }
                        }
                    }
                    break;
                }
                case 2:{
                    boolean c2=true;
                    while(c2){
                        rds.menu2();
                        int m2=scanner.nextInt();
                        scanner.nextLine();
                        switch(m2){
                            case 1:{
                                System.out.println("Enter a food name:");
                                String name = scanner.nextLine();
                                List<Food> flist = rds.search21(name);
                                if (!flist.isEmpty()) {
                                    for (Food f : flist) {
                                        f.print();
                                    }
                                } else {
                                    System.out.println("No such food item with this name.");
                                }
                                break;
                            }
                            case 2:{
                                System.out.println("Enter a restaurant name:");
                                String restaurant_name=scanner.nextLine();
                                System.out.println("Enter a food name:");
                                String food_name=scanner.nextLine();
                                Food f=rds.search22(restaurant_name,food_name);
                                if(f!=null){
                                    f.print();
                                }
                                else{
                                    System.out.println("No such food item with this name on the menu of this restaurant");
                                }
                                break;
                            }
                            case 3:{
                                System.out.println("Enter a food category:");
                                String category = scanner.nextLine();
                                List<List<Food>> flist = rds.search23(category);
                                if(flist.isEmpty()){
                                    System.out.println("No such food item with this category");
                                }
                                else{
                                    for (List<Food> restaurantFoodList : flist) {
                                        for (Food food : restaurantFoodList) {
                                            food.print();
                                        }
                                    }
                                }
                                break;
                            }
                            case 4:{
                                System.out.println("Enter a restaurant name:");
                                String rname=scanner.nextLine();
                                System.out.println("Enter category name:");
                                String cname=scanner.nextLine();
                                List<Food>flist=new ArrayList<>();
                                flist=rds.search24(rname,cname);
                                if(!flist.isEmpty()) {
                                    for (Food f : flist) {
                                        f.print();
                                    }
                                }
                                else{
                                    System.out.println(" No such food item with this category on the menu of this restaurant");
                                }
                            break;
                            }
                            case 5:{
                                System.out.println("Enter two price range:");
                                double a=scanner.nextDouble();
                                double b= scanner.nextDouble();
                                scanner.nextLine();
                                List<List<Food>>flist=rds.search25(a,b);
                                if(!flist.isEmpty()) {
                                    for (List<Food> restaurantFoodList : flist) {
                                        for (Food food : restaurantFoodList) {
                                            food.print();
                                        }
                                    }
                                }
                                else{
                                    System.out.println("No such food item with this price range.");
                                }
                             break;
                            }
                            case 6:{
                                System.out.println("Enter two price range:");
                                double a= scanner.nextDouble();
                                double b= scanner.nextDouble();
                                scanner.nextLine();
                                System.out.println("Enter restaurant name:");
                                String name=scanner.nextLine();
                                List<Food>flist=rds.search26(a,b,name);
                                if(!flist.isEmpty()){
                                    for(Food f:flist){
                                        f.print();
                                    }
                                }
                                else {
                                    System.out.println("No such food item with this price range on the menu of this restaurant");
                                }
                                break;
                            }
                            case 7:{
                                System.out.println("Enter a restaurant name:");
                                String name= scanner.nextLine();
                                Food ans=rds.search27(name);
                                if(ans!=null){
                                    ans.print();
                                }
                                break;
                            }
                            case 8:{
                               Map<String,Integer>rdata=new HashMap<>();
                               rdata=rds.search28();
                                for (Map.Entry<String, Integer> entry : rdata.entrySet()) {
                                    System.out.println(entry.getKey() + ": " + entry.getValue());
                                }
                                break;
                            }
                            case 9:{
                                c2=false;
                            }
                            default:{
                                System.out.println("Wrong option.");
                            }
                        }
                    }
                    break;
                }
                case 3:{
                    StringBuilder line=new StringBuilder();
                    System.out.println("Enter restaurant ID(int):");
                    String id=scanner.nextLine();
                    System.out.println("Enter restaurant name:");
                    String name= scanner.nextLine();
                    if(!rds.ispresent(name)) {
                        line.append(id).append(",");
                        line.append(name).append(",");
                        System.out.println("Enter Score(double):");
                        String score = scanner.nextLine();
                        line.append(score).append(",");
                        System.out.println("Enter price($,$$ or &&&):");
                        String price = scanner.nextLine();
                        line.append(price).append(",");
                        System.out.println("Enter zip code:");
                        String zipcode = scanner.nextLine();
                        line.append(zipcode).append(",");
                        List<String> categories = new ArrayList<>();
                        int n;
                        System.out.println("How many categories you want to add(<=3):");
                        n = scanner.nextInt();
                        scanner.nextLine();
                        for (int i = 0; i < n; i++) {
                            System.out.println("Enter category " + (i + 1) + ":");
                            String category = scanner.nextLine();

                            if (!category.isEmpty()) {
                                line.append(category).append(",");
                                categories.add(category);
                            } else {
                                break;
                            }
                        }
                        if (!line.isEmpty() && line.charAt(line.length() - 1) == ',') {
                            line.deleteCharAt(line.length() - 1);
                        }

                        Restaurant newRestaurant = new Restaurant(Integer.parseInt(id), name, Double.parseDouble(score), price, zipcode, categories);
                        rds.search3(newRestaurant);
                        try (BufferedWriter bwr = new BufferedWriter(new FileWriter(OUTPUT_RESTAURANT_NAME,true))) {
                            bwr.newLine();
                            bwr.write(line.toString());
                            bwr.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                    else{
                        System.out.println("Already exists a restaurant with this name.");
                    }
                 break;
                }
                case 4:{
                    System.out.println("Enter restaurant name:");
                    String name;
                    name= scanner.nextLine();
                    if(rds.ispresent(name)) {
                        StringBuilder line = new StringBuilder();
                        System.out.println("Enter restaurant id:");
                        String id = scanner.nextLine();
                        line.append(id).append(",");
                        System.out.println("Enter food category:");
                        String category = scanner.nextLine();
                        line.append(category).append(",");
                        System.out.println("Enter food name:");
                        String foodname = scanner.nextLine();
                        line.append(foodname).append(",");
                        System.out.println("Enter food price:");
                        String price = scanner.nextLine();
                        line.append(price);
                        Food f = new Food(Integer.parseInt(id), category, foodname, Double.parseDouble(price));
                        if (!rds.FoodPresent(name, f)) {
                            rds.search4(name, f);
                            try (BufferedWriter bwm = new BufferedWriter(new FileWriter(OUTPUT_MENU_NAME,true))) {
                                bwm.newLine();
                                bwm.write(line.toString());
                                bwm.close();
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                        else{
                            System.out.println("Already an item named this exists in this restaurant.");
                        }
                    }
                    else{
                        System.out.println("No restaurant exists with this name.");
                    }
                    break;
                }
                case 5:{
                return;
                }
                default:{
                    System.out.println("Wrong option.");
                }
            }
        }

    }
}
