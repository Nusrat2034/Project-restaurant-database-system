import java.util.ArrayList;
import java.util.List;

public class Restaurant {
    private int ID;
    private String Name;
    private double Score;
    private String Price;
    private String ZipCode;
    private List<String>Category= new ArrayList<>();
    private List<Food>MenuCard= new ArrayList<>();
    public String getPrice() {
        return Price;
    }

    public List<String> getCategory() {
        return Category;
    }

    public String getZipCode() {
        return ZipCode;
    }
    public double getScore() {
        return Score;
    }
    public int getID() {
        return ID;
    }
    public String getName() {
        return Name;
    }
    public Restaurant(int ID, String Name, double Score, String Price, String ZipCode,List<String>category){
        this.ID=ID;
        this.Name=Name;
        this.Score=Score;
        this.Price=Price;
        this.ZipCode=ZipCode;
        this.Category=category;
    }

    public void addFood(Food f) {
    MenuCard.add(f);
    }
    void print(){//for 1.1
        System.out.println("Restaurant Id: "+ID);
        System.out.println("Restaurant name: "+Name);
        System.out.println("Restaurant score: "+Score);
        System.out.println("The cost per person for an average meal: "+Price);
        System.out.println("Restaurant ZipCode: "+ZipCode);
        System.out.println("Categories:");
        for(String s:Category){
            System.out.println(s);
        }
    }

    public Food help21(String food_name) {//for 2.1 and 2.2
        for (Food f : MenuCard) {
            if ((f.getName().toLowerCase()).contains(food_name.toLowerCase())) {
                return f;
            }
        }
        return null;
    }

    //for 2.4
    public List<Food> help23(String food_category) {//for 2.3 and 2.4
    List<Food>ans=new ArrayList<>();
    for(Food f:MenuCard){
        if((f.getCategory().toLowerCase()).contains(food_category.toLowerCase())){
            ans.add(f);
        }
    }
    return ans;
    }
    public List<Food> help25(double a,double b){//for 2.5 and 2.6
         List<Food>ans=new ArrayList<>();
     for(Food f:MenuCard){
    if(f.getPrice()>=a && f.getPrice()<=b){
    ans.add(f);
    }
    }
    return ans;
    }
    //for 2.7
    public Food CostlyFood() {
        Food ans = null;  // Initialize ans to indicate no food item found yet
        for (Food f : MenuCard) {
            if (ans == null || f.getPrice() > ans.getPrice() ||
                    (f.getPrice() == ans.getPrice() && f.getName().compareTo(ans.getName()) > 0)) {
                ans = f;
            }
        }
        return ans;
    }
    public boolean isFoodPresent(Food food){
        for(Food f:MenuCard){
         if(f.getCategory().equalsIgnoreCase(food.getCategory()) && f.getName().equalsIgnoreCase(food.getName())){
             return true;
         }
        }
        return false;
    }
    //for 2.8
    int getTotalItem(){
        return MenuCard.size();
    }
}
