public class Food {
    private int Restaurant_ID;
    private String Category;
    private String Name;
    private double Price;

    public Food(int Restaurant_ID,String Category,String Name,double Price) {
        this.Restaurant_ID=Restaurant_ID;
        this.Category=Category;
        this.Name=Name;
        this.Price=Price;
    }

    public int getRestaurant_ID() {
        return Restaurant_ID;
    }
    public String getCategory() {
        return Category;
    }
    public String getName() {
        return Name;
    }
    public double getPrice() {
        return Price;
    }
    void print(){
        System.out.println("Restaurant ID:"+Restaurant_ID+", Food category:"+Category+", Food Name:"+Name+", Price:"+Price);
    }
}
